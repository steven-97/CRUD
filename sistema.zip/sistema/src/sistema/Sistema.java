/*
 Creación del paquete sistema
 */
package sistema;

import sistema.empleadosDAL.conexion;
import sistema.empleadosGUI.frmEmpleados;

/**
 * Se implementa la clase sistema
 * @author Daniel
 */
public class Sistema {

    /**
     * Argumentos generados a la clase principal por parte de netbeans
     * @param args the command 
     */
    public static void main(String[] args) {
        // TODO code application logic here
        conexion conex = new conexion();
        frmEmpleados ventanaEmpleado = new frmEmpleados();
   //     ventanaEmpleado.mostrarDatos();
    //    ventanaEmpleado.limpiar();
   //     ventanaEmpleado.recuperarDatosGUI();
        ventanaEmpleado.setVisible(true);
    }
    
}
